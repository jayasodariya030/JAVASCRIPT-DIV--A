function demoonclick(){
    alert("on click");
}

function demoonclick(){_
 alert("on double click");
}

function demofocus(){
      document.getElementById("textfocus"). style.backgroundcolor="yellow";
}

function demoonblur(){
      document.getElementById("textblur").style.backgroundColor="blue";
}

function demoonkeypress(){
    alert("keyprees done")
}

function demokeyup(){
    alert("keyup done");
}
