const country =["India","USA","Japan"];
for( C  of country){
     document.write("<br/>"+C);
}