for (let i=0; i < 5; i++){
     document.write("the number is " +i +"<br>");
}