const Human ={firstname:"jay",lastname:"asodaria",age:19};
for(let H in Human ) {
     document.write("<br/>"+H);
}
document.write("<br/>");
for(let H in Human) {
    document.write("<br/> "+Humam [H]);
}