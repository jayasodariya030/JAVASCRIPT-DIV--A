var x=50;
x += 45;
 document.write(x);
