var n1=10,n2="10"

//== enuai to valye only.
if (n1==n2){_
 document. write("<br/>same.");
}
else
{
     document.write("<br/>not same.");
}

//===enual to bvalue &type.
if (n1==n2 )
{
    document.write("<br/>not same.");
}
else
{
    document.write("<br/>not same.");
}
var n11=10,n22=10;

//== equal to value only 
if (n11==n22);
 document. write("<br/> same.");
{
    else
}
  document.write("<br/>not same.");
{

    //===equal to value & type.
    if(n11===n22)
    document.write("<br/>same.");
}
else
{
  document.write("<br/>nor same.");
}

// similar for not equal to and equal to value abd type.